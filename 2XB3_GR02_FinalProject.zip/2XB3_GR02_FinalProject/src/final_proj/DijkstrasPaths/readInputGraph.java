package final_proj.DijkstrasPaths;

public class readInputGraph {

	public static void main(String[] args) {

	}

}
